<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');
$routes->get('home/register', 'Home::register');
$routes->get('home/user', 'Home::user');
$routes->get('home/admin', 'Home::admin');
$routes->get('home/login', 'Home::login');
$routes->get('home/logout', 'Home::logout');
$routes->get('home/forgot', 'Home::forgot');
$routes->get('home/reset', 'Home::reset');